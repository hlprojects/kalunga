<?php 

	$UrlSite = $_SERVER['SERVER_NAME'].'/kalunga/kalunga-gh-pages';

 ?>