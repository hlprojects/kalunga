# Kalunga App

				<label>
					<input type="checkbox" id="notify" class=""  />
					<span>Notificar-me o funeral</span>
				</label> <br><br>


								<br><br>

				<div class="center-align">
					<button style="height: 50px;font-weight: bold!important;background-color:#19191900  !important;color: #212020!important;box-shadow: none!important;width: 160px; border-radius: 50px!important;    border: none!important;">Mais condolências...</button>
				</div>	
				<br><br><br>