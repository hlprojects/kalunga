		<footer class="page-footer" style="background-color: #191919 !important">
		  <div class="container">

		  	<div style="text-align: center;">
			  	<a href="#topo" style="color: white;font-weight: bold;width: 100%">
			  		<i class="material-icons" style="">keyboard_arrow_up</i><br>	
			  		voltar ao topo
			  	</a>		  		
		  	</div>

			<div class="row">

			  <div class="col l6 s12">
				<h5 class="white-text">Kalunga</h5>
				<p class="grey-text text-lighten-4">Obituário Online</p>
			  </div>
			  <div class="col l4 offset-l2 s12">
				<h5 class="white-text">Páginas</h5>
				<ul>
				  <li><a class="grey-text text-lighten-3" href="#!"></a></li>
				  <li><a class="grey-text text-lighten-3" href="#!"></a></li>
				  <li><a class="grey-text text-lighten-3" href="#!"></a></li>
				  <li><a class="grey-text text-lighten-3" href="#!"></a></li>
				</ul>
			  </div>
			</div>
		  </div>
		  <div class="footer-copyright">
			<div class="container">
			© 2019 HL inc Kalunga
			<a class="grey-text text-lighten-4 right" href="#!">Sobre</a>
			</div>
		  </div>
		</footer>