<?php 
	$conn = new PDO('mysql:host=localhost;dbname=hlkalunga_db','hlkalunga_user','hlkalunga_user');
 ?>