<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1" />
  	<meta name="theme-color" content="#999" />
  	<meta http-equiv="X-UA-Compatible" content="IE=edge">
  	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  	<link rel="manifest" href="../../../manifest.json">
	<link rel="shortcut icon" href="../../../favicon.ico" />
	<title>Memorial Paul Allen | Kalunga</title>

	<link rel="stylesheet" href="../../../build/css/materialize.min.css" />
	<link rel="stylesheet" href="../../../build/css/app.min.css" />
	<link rel="prefetch" href="../../../src/img/bg-flowers.jpg" />
	<link href="../../../build/material/material-icons.css" rel="stylesheet">

</head>
<body>

	<?php $initPath = '../../../'; include '../../../navBar.php'; ?>

	<main>
	<br>
		<h3 style="margin-left: 10px">Memoriais</h3>
		<section class="funeral-content">

			<div class="row">

							<div class="col s6 m4 l2 center-align " style="height: 200px;margin-top: 20px;">
								<a href="../memorial/publicar">
									<label class="valign-wrapper" for="fileFoto" style="background: white;height: 200px;width: 100%;border-radius: 10px;">
										<p style="width: 100%;">
											<i class="material-icons right" style="margin-top: 10px;margin-left: 0px; font-size: 70px!important;width: 100%;    color: #9e9e9e66;">add</i>
											<br>
											Publicar
											</p>
									</label>
								</a>
				            </div>

				<?php 
					include '../../../V1/memoriais/index.php';
				?>

			</div>

		</section>
	</main>

	<?php include '../../../footer.php'; ?>

	<!-- <script src="../../../node_modules/materialize-css/dist/js/materialize.min.js"></script> -->
	<script src="../../../build/jquery.min.js"></script>
	<script src="../../../build/materialize.min.js"></script>
	<script src="../../../build/swiper.min.js"></script>

	<script>
		$(".dropdown-trigger").dropdown();
	</script>
</body>
</html>